function N=numel(varargin)
%NUMEL (overloaded)

% Author Johan L�fberg 
% $Id: numel.m,v 1.1 2007/02/23 14:45:44 joloef Exp $   

N = 1;