function g = pennlp_con(i,x)

g = datasaver(4,x,i);


