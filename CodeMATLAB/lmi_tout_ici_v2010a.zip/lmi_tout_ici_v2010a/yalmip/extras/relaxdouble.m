function x = relaxdouble(x)
%RELAXDOUBLE (overloaded sdpvar/relaxdouble on double)

% Author Johan L�fberg
% $Id: relaxdouble.m,v 1.1 2004/11/19 11:38:21 johanl Exp $

% Do nothing, just return input.