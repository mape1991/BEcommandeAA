function varargout = pow10(varargin)
%POW10 (overloaded)

% Author Johan L�fberg
% $Id: pow10.m,v 1.1 2006/05/14 13:02:34 joloef Exp $

varargout{1} = 10.^varargin{1};
